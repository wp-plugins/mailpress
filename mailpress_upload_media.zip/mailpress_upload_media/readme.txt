=== MailPress_upload_media ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, MailPress, media, upload
Requires at least: 2.7
Stable tag: 3.0.1

This is just an addon for MailPress to use upload media wordpress facilities for images.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0.1 **

Enjoy !

== Installation ==

Unzip and copy mailpress_upload_media folder in wp-content/plugins

Extensions => activate MailPress_upload_media

MailPress>Write or Write>MailPress => new upload media button.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. upload media button with MailPress Write tinymce

== Log ==

**3.0.1**  	2009/04/
**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**
* Minor changes :
 - some changes about w3c recommendation requiring a space before /> for empty elements
 - some text changes accordingly
 - addon files renamed for consistency
 - preparing wp2.8

3.0	  	2009/04/12
* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress





