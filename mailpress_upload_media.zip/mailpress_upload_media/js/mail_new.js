
jQuery(document).ready( function() {
	// add media
	jQuery('#add_video').hide();
	jQuery('#add_audio').hide();
	jQuery('#add_media').hide();
});
