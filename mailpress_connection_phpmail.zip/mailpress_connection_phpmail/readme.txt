=== MailPress_connection_phpmail ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, connection, phpmail
Requires at least: 2.7
Stable tag: 3.0.2

This is just an addon for MailPress to replace default SMTP connection by native php mail connection.

== Description ==

** REQUIRES WORDPRESS 2.7 or 2.8 **

** Requires MailPress 3.0.2 **

Enjoy !

== Installation ==

Unzip and copy mailpress_connection_phpmail folder in wp-content/plugins

Plugins => activate MailPress_connection_phpmail 

MailPress>Settings or Settings>MailPress => new tab called 'PHP MAIL'.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Settings

== Log ==

** 3.0.2 ** 2009/05/

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

3.0.1 	2009/04/20
* Minor changes :
 - some changes about w3c recommendation requiring a space before /> for empty elements
 - some text changes accordingly
 - addon files renamed for consistency
 - preparing wp2.8

3.0	  	2009/04/12
* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
