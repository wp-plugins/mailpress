<?php
$tracking_reports  = array (	'user'	=>	array (	'u001'	=> array ('title' => __('Last 10 actions','MailPress')),
										'u002'	=> array ('title' => __('Last 10 mails','MailPress')),
										'u003'	=> array ('title' => __('Opened/day','MailPress')),
										'u004'	=> array ('title' => __('Clicks/day','MailPress')),
										'u005'	=> array ('title' => __('System info','MailPress')),
										'u006'	=> array ('title' => __('Geoip','MailPress'))
							),
					'mail'	=>	array (	'm001'	=> array ('title' => __('Last 10 actions','MailPress')),
										'm002'	=> array ('title' => __('Last 10 users','MailPress')),
										'm003'	=> array ('title' => __('Opened/day','MailPress')),
										'm004'	=> array ('title' => __('Clicks/day','MailPress')),
										'm005'	=> array ('title' => __('System info','MailPress')),
										'm006'	=> array ('title' => __('Geoip','MailPress'))
							)
		);
?>