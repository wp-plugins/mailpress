=== MailPress_autoresponder ===
Contributors: andre renaut
Tags: custom fields, mail, MailPress
Requires at least: 2.7
Stable tag: 3.0.1

This is just an addon for MailPress to manage autoresponders (based on wp-cron).

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0.1 **

Tested with Firefox3, Internet Explorer 7, Safari 3.1 (Windows XP)

Enjoy !

== Installation ==

Unzip and copy mailpress_autoresponder folder in wp-content/plugins

Plugins => activate MailPress_autoresponder

MailPress>Settings or Settings>MailPress => new tab called 'Autoresponders'.

New menu item Tools>Autoresponders or Mails>Autoresponders.

+ See MailPress mail detailled page.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Settings	
2. Autoresponders page (add)
3. Linking a mail to an autoresponder with its schedule
2. Autoresponders page (update)

== Log ==

**3.0.1**  	2009/04/

* Minor changes :
 - some changes about w3c recommendation requiring a space before /> for empty elements
 - some text changes accordingly
 - addon files renamed for consistency
 - preparing wp2.8

 - bug fixed : autoresponders only activated when admin connected !.
 - bug fixed : columns management on autoresponder list.
 - mails involved in autoresponders have a specific icon in mails list.


3.0	  	2009/04/12

* First release

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
