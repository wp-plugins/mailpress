=== MailPress_extra_form_mail_new ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, MailPress, mail_new, theme
Requires at least: 2.7
Stable tag: 3.0.2

This is just an addon for MailPress to temporarily change the MailPress theme on MailPress Write page.

== Description ==

** REQUIRES WORDPRESS 2.7 or 2.8 **

** Requires MailPress 3.0.2 **

Add a dropdown select to MailPress Write page to change temporarily the MailPress theme.

**You can temporarily change the theme under the Write page.**
**This information is not memorized.**
**If you send the draft from the list, the current mailpress theme applies.**

Enjoy !

== Installation ==

Unzip and copy mailpress_extra_form_mail_new folder in wp-content/plugins

Extensions => activate MailPress_extra_form_mail_new

MailPress Write page => new dropdown select.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. dropdown select on MailPress Write panel

== Log ==

** 3.0.2 ** 2009/05/

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

3.0.1 	2009/04/20
* Minor changes :
 - some changes about w3c recommendation requiring a space before /> for empty elements
 - some text changes accordingly

3.0	  	2009/04/12
* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
