=== MailPress_mailing_lists ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, MailPress, user, users, mailing list, mailing lists
Requires at least: 2.7
Stable tag: 3.0

This is just an addon for MailPress to manage mailing lists.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0 **

Tested with Firefox3, Internet Explorer 7, Safari 3.1 (Windows XP)

Enjoy !

== Installation ==

Unzip and copy mailpress_mailing_lists folder in wp-content/plugins

Plugins => activate MailPress_mailing_lists

MailPress>Settings or Settings>MailPress => new tab called 'Mailing list'.

New menu item Mails>Mailing lists.

See also MailPress user detailled page and Add new page.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Settings
2. Manage Mailing lists
3. Mailing lists in Write page
4. Mailing lists in MailPress users page
5. Mailing lists in MailPress user page
6. Subscription management including Mailing lists
7. if you are using 'mailpress_roles_and_capabilities', do not forget to grant access if necessary

== Log ==

**3.0**  	2009/04/12

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

* bugs : (fixed) mailing list not added to mp user when registering (using addon mailpress_sync_wordpress_user).

* tiny changes (code clean up).

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
