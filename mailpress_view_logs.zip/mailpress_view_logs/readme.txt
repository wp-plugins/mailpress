=== MailPress_view_logs ===
Contributors: andre renaut
Tags: logs, MailPress
Requires at least: 2.7
Stable tag: 3.0

This is just an add_on for MailPress to view logs.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0 **

Tested with Firefox3, Internet Explorer 7, Safari 3.1 (Windows XP)

Enjoy !

== Installation ==

Unzip and copy mailpress_view_logs folder in wp-content/plugins

Plugins => activate MailPress_view_logs

New menu option

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. View log page
2. if you are using 'mailpress_roles_and_capabilities', do not forget to grant access if necessary

== Log ==

**3.0**  	2009/04/12

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
