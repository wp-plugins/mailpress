=== MailPress_reset ===
Contributors: andre renaut
Tags: reset, MailPress
Requires at least: 2.7
Stable tag: 3.0.1

Activating this plugin will immediately delete all MailPress related data in the WordPress & MailPress tables!

== Description ==

This is a one shot plugin. 

== Installation ==

** Warning : Activating this plugin will immediately delete all MailPress related data in the WordPress & MailPress tables! **
** Warning : Activating this plugin will immediately delete all MailPress related data in the WordPress & MailPress tables! **
** Warning : Activating this plugin will immediately delete all MailPress related data in the WordPress & MailPress tables! **

Unzip and copy mailpress_reset folder in wp-content/plugins.
Extensions => Deactivate all mailpress plugins.
Extensions => activate MailPress_reset.
Extensions => deactivate MailPress_reset.

If you want to completely uninstall MailPress, go to your mysql admin panel (PhpMyAdmin ?) and drop the tables prefixed by 'MailPress_' or 'mailpress_'.

== Frequently Asked Questions ==

Support is provided thru http://groups.google.com/group/mailpress

== Log ==

**3.0.1**  	2009/04/

* Adding taxonomy of MailPress_autoresponder

3.0  		2009/04/12

* First release

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
