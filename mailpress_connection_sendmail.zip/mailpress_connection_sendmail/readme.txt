=== MailPress_connection_sendmail ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, connection, sendmail
Requires at least: 2.7
Stable tag: 3.0

This is just an addon for MailPress to replace default SMTP connection by SendMail connection.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0 **

Enjoy !

== Installation ==

Unzip and copy mailpress_connection_sendmail folder in wp-content/plugins

Plugins => activate MailPress_connection_sendmail 

MailPress>Settings or Settings>MailPress => new tab called 'SENDMAIL'.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Settings

== Log ==

**3.0**  	2009/04/12

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
