=== MailPress_roles_and_capabilities ===
Contributors: andre renaut
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, role, roles, capabilities, capability
Requires at least: 2.7
Stable tag: 3.0.1

This is just an addon for MailPress to manage capabilities.

== Description ==

** Requires MailPress 3.0.1 **

Supported languages : English, French	(.pot provided)

Enjoy !

== Installation ==

Unzip and copy mailpress_roles_and_capabilities folder in wp-content/plugins

Plugins => activate MailPress_roles_and_capabilities 

MailPress>Settings or Settings>MailPress => new tab called 'R&C'.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Settings

== Log ==

** 3.0.1 ** 2009/04/20
**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**
* Only the version number has changed

3.0	  	2009/04/12
* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
