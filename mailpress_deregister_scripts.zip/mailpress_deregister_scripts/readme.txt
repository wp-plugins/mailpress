=== MailPress_deregister_scripts ===
Contributors: andre renaut
Tags: mail, MailPress, prototype, plugin, conflict
Requires at least: 2.7
Stable tag: 3.0

This is just an addon for MailPress to remove unwelcomed scripts from MailPress Pages.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0 **

Enjoy !

== Installation ==

Unzip and copy mailpress_deregister_scripts folder in wp-content/plugins

Plugins => activate MailPress_deregister_scripts

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Log ==

**3.0**  	2009/04/12

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

* A html comment listing the deregistered script is inserted in the mailpress pages for debugging purpose.
<!-- MailPress_deregister_scripts : prototype,Umapper -->

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
