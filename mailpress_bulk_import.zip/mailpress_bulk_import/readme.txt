=== MailPress_bulk_import ===
Contributors: andre renaut, daniel caleb
Tags: mail, subscribe, newsletter, Wordpress, Plugin, swiftmailer, MailPress, user, users
Requires at least: 2.7
Stable tag: 3.0

This is just an addon for MailPress to import users.

== Description ==

** REQUIRES WORDPRESS 2.7 **

** Requires MailPress 3.0 **

Add a form at the END of MailPress users list to "bulk add" new MailPress users.

Enjoy !

== Installation ==

Unzip and copy mailpress_bulk_import folder in wp-content/plugins

Plugins => activate MailPress_bulk_import

MailPress>Users or Users>MailPress => new "Bulk Add" form.

== Frequently Asked Questions ==

**See** plugin MailPress plugin page at http://www.mailpress.org

Support is provided thru http://groups.google.com/group/mailpress

== Screenshots ==

1. Form "Bulk Add"
2. New MailPress users
3. New MailPress users processed

== Log ==

**3.0**  	2009/04

**FOR UPDATE FROM A FORMER RELEASE DO NOT FORGET TO DEACTIVATE/UPDATE/ACTIVATE THE PLUGIN !**

* Only the version number has changed

== Next features ==

**Any new idea** or **code improvement** can be posted at : http://groups.google.com/group/mailpress
